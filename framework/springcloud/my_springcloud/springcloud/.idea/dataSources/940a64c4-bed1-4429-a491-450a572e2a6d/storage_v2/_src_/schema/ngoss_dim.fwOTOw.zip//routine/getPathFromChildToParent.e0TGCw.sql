create function getPathFromChildToParent(rootId int) returns varchar(1000)
BEGIN
DECLARE sParentList varchar(1000);
DECLARE sParentTemp varchar(1000);
declare  snamelist varchar(1000) default '';
declare snametemp varchar(1000);
SET sParentTemp =cast(rootId as CHAR);
WHILE sParentTemp is not null DO
IF (sParentList is not null ) THEN
SET sParentList = concat(sParentTemp,',',sParentList);
ELSE
SET sParentList = concat(sParentTemp);
END IF;
SELECT group_concat(parent_id) , group_concat(name) INTO sParentTemp, snametemp FROM web_menu where FIND_IN_SET(id,sParentTemp)>0;
set snamelist = concat(snametemp,'/',snamelist);
END WHILE;

RETURN snamelist;
END;

