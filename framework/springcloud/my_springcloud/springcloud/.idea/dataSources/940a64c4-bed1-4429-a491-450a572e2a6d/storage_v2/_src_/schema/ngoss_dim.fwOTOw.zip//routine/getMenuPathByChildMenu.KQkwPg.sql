create function getMenuPathByChildMenu(comId int) returns varchar(1000)
BEGIN
	DECLARE sTemp VARCHAR(1000);
	DECLARE sTempPar VARCHAR(1000); 
  DECLARE sTempName VARCHAR(1000); 
	SET sTemp = ''; 
	SET sTempPar =cast(comId as char); 
  SET sTempName = '';
	
	#循环递归
	WHILE sTempPar is not null DO 
		 IF sTemp != '' THEN
			SET sTemp = concat(sTempName,'/',sTemp);
		 ELSE
			SET sTemp = sTempName;
		 END IF;

		SELECT group_concat(parent_id), group_concat(name) INTO sTempPar, sTempName FROM web_menu where parent_id <> id and FIND_IN_SET(id,sTempPar)>0; 

	END WHILE; 
	
RETURN sTemp; 
END;

