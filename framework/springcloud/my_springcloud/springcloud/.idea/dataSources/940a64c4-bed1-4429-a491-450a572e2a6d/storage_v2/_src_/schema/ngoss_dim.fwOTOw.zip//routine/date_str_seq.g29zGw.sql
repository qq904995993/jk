create function date_str_seq(startDate int, endDate int) returns varchar(2000)
BEGIN
  DECLARE resultStr varchar(2000) DEFAULT '';
  DECLARE counter INT;
  SET counter=startDate;
  WHILE counter<=endDate DO
     SET resultStr=CONCAT(resultStr,'\'',counter,'\',');
		 set counter=cast(DATE_FORMAT(DATE_ADD(STR_TO_DATE(counter,'%Y%m%d'),INTERVAL 1 day),'%Y%m%d') as UNSIGNED);
   END WHILE;
	RETURN SUBSTR(resultStr,1,LENGTH(resultStr));
END;

