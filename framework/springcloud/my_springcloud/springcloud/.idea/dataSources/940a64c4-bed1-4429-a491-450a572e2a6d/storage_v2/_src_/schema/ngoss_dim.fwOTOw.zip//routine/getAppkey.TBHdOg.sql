create function getAppkey(seq_name char(20)) returns bigint
begin  
 UPDATE seq_appkey SET incre_id=last_insert_id(incre_id+1) WHERE seq_name=seq_name;  
 RETURN last_insert_id();  
end;

